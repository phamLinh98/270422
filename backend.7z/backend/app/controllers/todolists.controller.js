// const { async } = require("rxjs");
const db = require("../models");
//call toi model de lay thanh phan trong bang csdl
const Todolists  = db.todolists;
//connect bang todolist
const Op = db.Sequelize.Op;

//Chuc nang them ban ghi
//1 Kiem tra va bat loi neu co
exports.create = async (req, res) => {
    if (!req.body.job) {
        res.status(400).send({
            messenger: "Job cannot empty"});
        return;
    }
    try {
        const todolists = await Todolists.create({
            job: req.body.job,
            description: req.body.description,
        });
        res.json({data: todolists });
    } catch (err) {
        console.log(err);
        res.status(500).send({
            message: err.message || "Some error occurred while creating the record.",
        });
    }
};

exports.findAll = (req, res) => {
    const query = `SELECT * FROM todolists ORDER BY id ASC`;
    Todolists.sequelize.query(query, { type: database.sequelize.QueryTypes.SELECT })
        .then(data => {
            res.send(data)

        })
        .catch(err => {
            res.status(500).send({
                message:
                    err.message || "Please check records"
            });
        });
};