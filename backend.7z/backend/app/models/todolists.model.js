module.exports = (sequelize, Sequelize) => {
    const todolists = sequelize.define("todolists", {
        job: {
            type: Sequelize.STRING
        },
        description: {
            type: Sequelize.STRING
        }

    });

    return todolists;
};