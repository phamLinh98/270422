module.exports = app => {
    const todolists = require("../controllers/todolists.controller.js");
  
    var router = require("express").Router();
  
    // Create a new Tutorial
    router.post("/", todolists.create);
  
    // Retrieve all Tutorials
    router.get("get", todolists.findAll);
  
    // // Retrieve all published Tutorials
    // router.get("/published", tutorials.findAllPublished);
  
    // // Retrieve a single Tutorial with id
    // router.get("/:id", tutorials.findOne);
  
    // // Update a Tutorial with id
    // router.put("/:id", tutorials.update);
  
    // // Delete a Tutorial with id
    // router.delete("/:id", tutorials.delete);
  
    // // Create a new Tutorial
    // router.delete("/", tutorials.deleteAll);
  
    // router.query("/query/:param", async (req, res) => {
    //   res.send(await db.query(req))
    // });
  
    app.use('/api/todolists', router);
  };s