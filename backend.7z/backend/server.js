const express = require('express')
const app = express()
const cors = require("cors");
const port = 8080
const { Sequelize } = require('sequelize');

var corsOptions = {
  origin: "http://localhost:8081"
};
app.use(cors(corsOptions)); //1
app.use(express.json()); //2
app.use(express.urlencoded({ extended: true })); //3

app.get('/', (req, res) => {
  res.json({
    messenge: "Hello There"
  })
})
const db = require("./app/models");
//const User = require('./backend/app/models');
db.sequelize.sync()
  .then(() => {
    console.log("Connect Thanh Cong");
  })
  .catch((err) => {
    console.log("Connect That Bai")
  });
require("./app/routes/todolists.routes")(app);
app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})