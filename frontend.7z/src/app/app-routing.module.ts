import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListComponent } from './components/listpage/list.component';
import { AddComponent } from './components/addpage/add.component'
const routes: Routes = [
  {path: '', redirectTo:'todolist',pathMatch : 'full'},
  {path:'list',component:ListComponent},
  {path:'add', component:AddComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
