import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Todolist } from '../models/todolist.model';

const baseUrl = 'http://localhost:8080/api/todolist/list';
const AddUrl =  'http://localhost:8080/api/todolist/add';
@Injectable({
  providedIn: 'root'
})
export class TodolistService {

  constructor(private http:HttpClient) {}
    getAll(): Observable<Todolist[]>
    {
      return this.http.get<Todolist[]>(baseUrl);
    }
    create(data:any): Observable<any>
    {
      return this.http.post<Todolist[]>(AddUrl, data);
    }
   }

