import { Component, OnInit } from '@angular/core';
import { Todolist } from 'src/app/models/todolist.model';
import { TodolistService } from 'src/app/services/todolist.service';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  todolist: Todolist = {
    job: '',
    description: ''
  }
  //submitted = false;
  constructor(private todoService: TodolistService){}
  ngOnInit(): void {
  }
  saveTodolist(): void {
    const data = {
      job: this.todolist.job,
      description: this.todolist.description
    };
    this.todoService.create(data)
       console.log(data);
      // .subscribe({
        
      //   next: (res) => {

      //     console.log(res);
      //     // console.log(data);
        
      //   },
      
      //   error: (e) => console.error(e)
      // });
  }
  newTodolist():void{
    this.todolist = {
      job:'',
      description: ''
    }
  }

}
