import { Component, OnInit } from '@angular/core';
import { Todolist } from 'src/app/models/todolist.model';
import { TodolistService } from 'src/app/services/todolist.service';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  todolist?: Todolist[];
  currentTodolist: Todolist = {};
  currentIndex = -1;
  title = '';
  constructor(private todolistService: TodolistService) { }
  ngOnInit(): void {
    this.retrieveTodolist();
  }
  retrieveTodolist(): void {
    this.todolistService.getAll()
      .subscribe({
        next: (data) => {
          this.todolist = data;
          console.log(data);
        },
        error: (e) => console.error(e)
      });
  }
  // refreshList(): void {
  //   this.retrieveTutorials();
  //   this.currentIndex = -1;
  //   this.currentTodolist = {};
  // }
  // setActiveTodolist(todolist: Todolist, index: number): void {
  //   this.currentTodolist = todolist;
  //   this.currentIndex = index;
  // }
}


