export class Todolist {
    id?: any;
    job?:string;
    description?:string;
    created_at?:Date
}

