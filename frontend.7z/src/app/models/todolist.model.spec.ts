import { Todolist } from './todolist.model';

describe('Todolist', () => {
  it('should create an instance', () => {
    expect(new Todolist()).toBeTruthy();
  });
});
